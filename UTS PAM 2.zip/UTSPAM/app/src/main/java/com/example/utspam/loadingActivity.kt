package com.example.utspam

import android.content.Intent
import android.os.Bundle
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*

class LoadingActivity : AppCompatActivity() {

    private lateinit var progressBar: ProgressBar
    private lateinit var progressText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_loading)

        progressBar = findViewById(R.id.progressBar)
        progressText = findViewById(R.id.tvProgress)

        val employee: Employee = intent.getSerializableExtra("employeeData") as Employee
        CoroutineScope(Dispatchers.Main).launch {
            for (i in 1..100) {
                delay(50) // Delay untuk simulasi loading
                progressBar.progress = i
                progressText.text = "$i%"
            }
            navigateToDetails(employee)
        }
    }

    private fun navigateToDetails(employee: Employee) {
        val intent = Intent(this, SalaryDetailsActivity::class.java).apply {
            putExtra("employeeData", employee)
            startActivity(this)
        }
        finish()
    }
}

private fun Intent.putExtra(s: String, employee: Employee) {

}
