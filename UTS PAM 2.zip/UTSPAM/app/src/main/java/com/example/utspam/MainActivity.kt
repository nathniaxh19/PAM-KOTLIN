package com.example.utspam

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.content.Intent
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        var recyclerView: RecyclerView? = null
        val employeeList = listOf(
            Employee("Alice", "Manager", 12000000),
            Employee("Bob", "Developer", 9000000),
            Employee("Charlie", "Designer", 8000000)
        )

        fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)

            recyclerView = findViewById(R.id.recyclerView)
            recyclerView.layoutManager = LinearLayoutManager(this)
            recyclerView.adapter = EmployeeAdapter(employeeList) { employee ->
                val intent = Intent(this, LoadingActivity::class.java).also {
                    it.putExtra("employeeData", employee)
                    startActivity(it)
                }

            }
        }
    }
}