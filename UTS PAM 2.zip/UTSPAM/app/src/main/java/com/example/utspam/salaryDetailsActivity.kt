package com.example.utspam

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SalaryDetailsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_salary_details)

        val employee: Employee = intent.getSerializableExtra("employeeData") as Employee
        val detailsText: TextView = findViewById(R.id.tvEmployeeDetails)
        val salaryText: TextView = findViewById(R.id.tvSalary)
        val backButton: Button = findViewById(R.id.btnBack)

        detailsText.text = "${employee.name} - ${employee.position}"
        salaryText.text = "Salary: Rp ${employee.salary}"

        backButton.setOnClickListener {
            finish()
        }
    }
}
