package com.example.utspam

data class Employee(
    val name: String,
    val position: String,
    val salary: Int
)
