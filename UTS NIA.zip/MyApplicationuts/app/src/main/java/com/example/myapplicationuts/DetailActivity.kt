package com.example.myapplicationuts

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val nama = intent.getStringExtra("NAMA")
        val gaji = intent.getDoubleExtra("GAJI", 0.0)

        findViewById<TextView>(R.id.tvNamaDetail).text = nama
        findViewById<TextView>(R.id.tvGajiDetail).text = "Rp $gaji"

    }
}
