package com.example.myapplicationuts

class Pegawai {
    val id: Int = 0
    val nama: String = ""
    val gaji: Double = 0.0
}
