package com.example.myapplicationuts

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.content.Intent
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.*
import com.example.myapplicationuts.DummyData

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        val pegawaiList = DummyData.getPegawaiList()

        val adapter = PegawaiAdapter(pegawaiList = Pegawai) { pegawai ->
            showLoadingAndNavigate(pegawai)
        }

        LinearLayoutManager(this).also { it.also { recyclerView.layoutManager = it } }
        recyclerView.adapter = adapter
    }

    private fun showLoadingAndNavigate(pegawai: Pegawai) {
        GlobalScope.launch(Dispatchers.Main) {
            val progressDialog = ProgressDialog(this@MainActivity)
            progressDialog.setTitle("Loading")
            progressDialog.setMessage("Loading data...")
            progressDialog.setCancelable(false)
            progressDialog.show()

            withContext(Dispatchers.Default) {
                for (i in 1..10000) {
                }
            }

            progressDialog.dismiss()
            val intent = Intent(this@MainActivity, DetailActivity::class.java)
            intent.putExtra("NAMA", pegawai.nama)
            intent.putExtra("GAJI", pegawai.gaji)
            startActivity(intent)
        }

    }
}