package com.example.myapplicationuts

import com.example.myapplicationuts.Pegawai

object DummyData {
    fun getPegawaiList(): List<Any> {
        return listOf(
            Pegawai1 (1, "Mingyu", 5000000.0),
            Pegawai2 (2, "Jeha", 4800000.0),
            Pegawai3 (3, "Anna", 6000000.0),
            Pegawai4 (4, "Jay", 5200000.0),
            Pegawai5 (5, "Kai", 5500000.0)
    }
}