package com.example.myapplicationuts
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import android.widget.TextView


private var Any.text: String
    get() {}
    set(value) {}

class PegawaiAdapter(
    private val pegawaiList: List<Pegawai>,
    private val onItemClick: (Pegawai) -> Unit
) : RecyclerView.Adapter<PegawaiAdapter.PegawaiViewHolder>() {

    inner class PegawaiViewHolder(itemView: View,
                                  private val namaTextView: Any = itemView.findViewById(R.id.tvNama)
    ) : RecyclerView.ViewHolder(itemView) {

        fun bind(pegawai: Pegawai) {
            namaTextView.text = pegawai.nama
            itemView.setOnClickListener { onItemClick(pegawai) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PegawaiViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_pegawai, parent, false)
        return PegawaiViewHolder(view)
    }

    override fun onBindViewHolder(holder: PegawaiViewHolder, position: Int) {
        holder.bind(pegawaiList[position])
    }

    override fun getItemCount(): Int = pegawaiList.size
}

